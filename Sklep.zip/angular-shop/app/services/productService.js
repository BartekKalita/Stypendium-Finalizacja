angular.module('shopApp').service('productService', function() {
    this.getProducts = function() {
      return [
        { id: 1, name: 'Telefon', price: 500 },
        { id: 2, name: 'Telewizor', price: 1500 },
        { id: 3, name: 'Pralka', price: 800 }
      ];
    };
  });
  