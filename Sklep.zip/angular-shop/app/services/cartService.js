angular.module('shopApp').service('cartService', function() {
    var cart = [];
    var totalPrice = 0;
    var totalDiscount = 0;
    var itemCount = {};

    this.setCart = function(cartItems) {
        cart = cartItems;
        totalPrice = cart.reduce((sum, product) => sum + product.price, 0);
        totalDiscount = totalPrice > 1000 ? totalPrice * 0.1 : 0;

        // Calculate item counts
        itemCount = {};
        cart.forEach(function(product) {
            if (!itemCount[product.id]) {
                itemCount[product.id] = {
                    count: 1,
                    product: product
                };
            } else {
                itemCount[product.id].count++;
            }
        });
    };

    this.getCart = function() {
        return cart;
    };

    this.getTotalPrice = function() {
        return totalPrice;
    };

    this.getTotalDiscount = function() {
        return totalDiscount;
    };

    this.getItemCount = function() {
        return itemCount;
    };
});
