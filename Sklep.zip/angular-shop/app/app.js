angular.module('shopApp', ['ngRoute']).config(['$routeProvider', function($routeProvider) {
  $routeProvider
      .when('/', {
          templateUrl: 'views/shop.html',
          controller: 'shopController'
      })
      .when('/summary', {
          templateUrl: 'views/summary.html',
          controller: 'summaryController'
      })
      .when('/thankyou', {
        templateUrl: 'views/thankyou.html', 
        controller: 'thankyouController' 
    })
      .otherwise({
          redirectTo: '/'
      });
}]);
