angular.module('shopApp').controller('summaryController', ['$scope', '$location', 'cartService', '$timeout', function($scope, $location, cartService, $timeout) {
    $scope.init = function() {
        $scope.cart = cartService.getCart();
        $scope.totalPrice = cartService.getTotalPrice();
        $scope.totalDiscount = cartService.getTotalDiscount();
        $scope.itemCount = cartService.getItemCount();
        
        // Generuj kody po ustawieniu danych
        $timeout(function() {
            $scope.generateBarcode();
            $scope.generateQRCode();
        }, 0);

        $scope.redirectToThankYouPage = function() {
            
            $location.path('/thankyou');

            
        };
    };

    $scope.generateBarcode = function() {
        var orderId = "ORDER-" + Date.now(); // Generowanie unikalnego identyfikatora zamówienia
        JsBarcode("#barcode", orderId, {
            format: "CODE128",
            displayValue: true,
            fontSize: 18
        });
    };

    $scope.generateQRCode = function() {
        var qrData = "Suma: " + Date.now();
        var qrCodeElement = document.getElementById("qrcode");
        qrCodeElement.innerHTML = "";
        new QRCode(qrCodeElement, {
            text: qrData,
            width: 128,
            height: 128
        });
    };
    
    // Wywołaj funkcję init, gdy kontroler zostanie załadowany
    $scope.init();
}]);
