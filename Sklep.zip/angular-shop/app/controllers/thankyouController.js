angular.module('shopApp').controller('thankyouController', ['$scope', '$location', function($scope, $location) {
    $scope.init = function() {
        

        $scope.redirectToHomePage = function() {
            
            $location.path('/');

            
        };
    };

    $scope.init();
}]);
