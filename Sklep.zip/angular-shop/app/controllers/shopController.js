angular.module('shopApp').controller('shopController', ['$scope', '$location', 'productService', 'cartService', function($scope, $location, productService, cartService) {
  $scope.products = productService.getProducts();
  $scope.cart = [];
  $scope.total = 0;
  $scope.discount = 0;
  $scope.finalTotal = 0;

  $scope.addToCart = function(product) {
      $scope.cart.push(product);
      $scope.calculateTotal();
      $scope.calculateItemCount();
  };

  $scope.calculateTotal = function() {
      $scope.total = $scope.cart.reduce((sum, product) => sum + product.price, 0);
      if ($scope.total > 1000) {
          $scope.discount = $scope.total * 0.1;
      } else {
          $scope.discount = 0;
      }
      $scope.finalTotal = $scope.total - $scope.discount;
  };

 

  $scope.removeFromCart = function(product) {
      var index = $scope.cart.indexOf(product);
      if (index !== -1) {
          $scope.cart.splice(index, 1);
          $scope.calculateTotal();
      }
      $scope.calculateItemCount();
  };

  $scope.calculateItemCount = function() {
      $scope.itemCount = {};
      $scope.totalItems = 0;
      
      $scope.cart.forEach(function(product) {
          if (!$scope.itemCount[product.id]) {
              $scope.itemCount[product.id] = 1;
          } else {
              $scope.itemCount[product.id]++;
          }
          $scope.totalItems++;
      });
  };
  
  // Wywołanie funkcji przy inicjalizacji
  $scope.calculateItemCount();
  
  $scope.finalizePurchase = function() {
      
      if ($scope.cart.length > 0) {
          
          cartService.setCart($scope.cart);
          $location.path('/summary');
          console.log("Po wywołaniu finalizePurchase"); // Debugowanie
      }
  };
}]);
